﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using System.Xml.Serialization;
using Faker;
using HtmlAgilityPack;

namespace Groups
{
    public class ListEmployee : List<Employee>
    {
        static Random _rand = new Random();
        private static int _counterMythicalEmployee = 50000;
        private static string _nameXmlName = "Names.xml";
        private static int _coutDirectionSite = 31885;// 31885 -- На сайті списків абітурієнтів стільки напрямків 
        private static string _pathSite = @"http://abit-poisk.org.ua/rate2014/direction/";

        public string NameXmlName
        {
            get { return _nameXmlName; }
            set { _nameXmlName = value; }
        }

        public int CoutDirectionSite
        {
            get { return _coutDirectionSite; }
            set { _coutDirectionSite = value; }
        }

        public string PathSite
        {
            get { return _pathSite; }
        }

        public static void SortEmployeesByAge(ref List<Employee> employees)
        {
            employees=employees.OrderBy(employee => employee.AgeInYears).ToList();
        }

        public int CounterMythicalEmployee
        {
            get { return _counterMythicalEmployee; }
            set { _counterMythicalEmployee = value; }
        }

        public static List<string> DeserializeNames()
        {
            Names names;
            var mySerializer = new XmlSerializer(typeof(Names));
            using (var fs = new FileStream(_nameXmlName, FileMode.Open))
            {
                names = (Names)mySerializer.Deserialize(fs);
                fs.Close();
            }
            while (names.Contains(null)) names.Remove(null);
            return names.ToList();
        }

        public static List<Employee> ParseOfRealData(List<string> names)
        {
            var list = new List<Employee>(names.Count);
            list.AddRange(names.AsParallel().Select(name => new Employee() 
            { 
                Identity = Guid.NewGuid(),
                Name = name,
                Email = name.GetEmail(),
                Gender = name.GetGender(),
                AgeInYears = _rand.Next(18, 60),
                Salary = _rand.Next(1800, 50000)
            }));
            return list;
        }

        public static List<Employee> CreateMythicalData()
        {
            var list = new List<Employee>(_counterMythicalEmployee);
            Parallel.For(0, _counterMythicalEmployee, new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount * 10 }, i =>
            {
                var name = Name.FullName();
                var employee = new Employee
                {
                    Identity = Guid.NewGuid(),
                    Name = name,
                    Email = Internet.Email(name),
                    AgeInYears = RandomNumber.Next(25, 80),
                    Salary = RandomNumber.Next(10000, 30000),
                    Gender = Gender.Transgender
                };
                list.Add(employee);
            });
            return list;
        }

        public static void InitialXmlNames()
        {
            var result = MessageBox.Show(File.Exists(_nameXmlName) ?
                "У вас уже есть файл с именами. Загрузки имен с сайта займет длительное время продолжить?"
                :"Загрузки имен с сайта займет длительное время продолжить?",
                "", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                var listName = ParseSiteForNamesList();
                //analog  (XmlSerializer and FileStream) for names
                //var xmlBank = new XDocument(new XElement("Names",
                //                     from name in listName
                //                     select new XElement("Name", name)));
                //xmlBank.Save("name.xml");
                var xmlSerializer = new XmlSerializer(typeof (Names));
                using (var fs = new FileStream(_nameXmlName, FileMode.OpenOrCreate))
                {
                    fs.SetLength(0);
                    xmlSerializer.Serialize(fs, listName);
                    fs.Flush();
                }
            }
        }

        public static Names ParseSiteForNamesList()
        {
            var nameList = new List<string>();
            Parallel.For(1, _coutDirectionSite, new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount * 10 }, i =>
            {
                var doc = new HtmlWeb().Load(string.Format(_pathSite, i));
                var nodes = doc.DocumentNode.SelectNodes("//tr[@class='success']//td[2]");// абітурієнти які зараховані і ні знаходяться в інших класах
                var nodes2 = doc.DocumentNode.SelectNodes("//tr[@class='info']//td[2]");
                if (nodes != null)
                    nameList.AddRange(nodes.Select(node => node.InnerText.Trim()));
                if (nodes2 != null)
                    nameList.AddRange(nodes2.Select(node => node.InnerText.Trim()));
            });
            var uniqueNames = new Names();
            for (var i = 0; i < nameList.Count; i++)
            {
                uniqueNames.Add(nameList[i]);
            }
            return uniqueNames;
        }
    }
}
