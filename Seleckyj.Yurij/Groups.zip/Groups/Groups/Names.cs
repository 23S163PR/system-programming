using System.Collections.Generic;
using System.Xml.Serialization;
namespace Groups
{
    /// <remarks/>
    [XmlTypeAttribute(AnonymousType = true)]
    [XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class Names : HashSet<string>
    {
        
    }
}