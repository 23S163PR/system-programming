﻿namespace Groups
{
    public enum Gender
    {
        Men,
        Woman,
        Transgender
    }
}