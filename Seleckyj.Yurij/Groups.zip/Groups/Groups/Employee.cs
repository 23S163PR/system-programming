using System;
using System.Collections;

namespace Groups
{
    /// <remarks/>
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class List
    {

        private Employee[] _employeesField;

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Employee", IsNullable = false)]
        public Employee[] Employees
        {
            get
            {
                return _employeesField;
            }
            set
            {
                _employeesField = value;
            }
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class Employee 
    {

        private Guid _identity;
        private string _name;
        private string _email;
        private int _ageInYears;
        private Gender _gender;
        private decimal _salary;

        /// <remarks/>
        public Guid Identity
        {
            get
            {
                return _identity;
            }
            set
            {
                _identity = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        /// <remarks/>
        public string Email
        {
            get
            {
                return _email;
            }
            set
            {
                _email = value;
            }
        }

        /// <remarks/>
        public int AgeInYears
        {
            get
            {
                return _ageInYears;
            }
            set
            {
                _ageInYears = value;
            }
        }

        /// <remarks/>
        public Gender Gender
        {
            get
            {
                return _gender;
            }
            set
            {
                _gender = value;
            }
        }

        /// <remarks/>
        public decimal Salary
        {
            get
            {
                return _salary;
            }
            set
            {
                _salary = value;
            }
        }
    }


}