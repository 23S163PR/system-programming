﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Serialization;
using Faker;
using HtmlAgilityPack;
using System.Windows.Threading;
namespace Groups
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ListEmployee _listEmployee;

        private readonly string _pathFileGroup1 = "Group_1.xml";
        private readonly string _pathFileGroup2 = "Group_2.xml";
        private readonly string _pathFileGroup3 = "Group_3.xml";
        private readonly string _pathFileGroup4 = "Group_4.xml";

        List<Employee> _group1 = new List<Employee>();
        List<Employee> _group2 = new List<Employee>();
        List<Employee> _group3 = new List<Employee>();
        List<Employee> _group4 = new List<Employee>();

        readonly Func<Employee, bool> _predicateGroup1 = emp => emp.AgeInYears >= 21 && emp.Salary > 15000;
        readonly Func<Employee, bool> _predicateGroup2 = emp => emp.Gender == Gender.Woman && (emp.Name.StartsWith("A") || emp.Name.StartsWith("А"));
        readonly Func<Employee, bool> _predicateGroup3 = emp => emp.Gender == Gender.Men && emp.Salary > 20000;
        readonly Func<Employee, bool> _predicateGroup4 = emp => emp.Gender == Gender.Transgender && emp.AgeInYears >= 50;

        public MainWindow()
        {
            _listEmployee = new ListEmployee();
            InitializeComponent();
        }


        private void SaveXml_OnClick(object sender, RoutedEventArgs e)
        {
            SortGroups();
            SaveLoadXml.SavetoXml(_pathFileGroup1, _group1);
            SaveLoadXml.SavetoXml(_pathFileGroup2, _group2);
            SaveLoadXml.SavetoXml(_pathFileGroup3, _group3);
            SaveLoadXml.SavetoXml(_pathFileGroup4, _group4);
        }
       

        private void LoadXml_OnClick(object sender, RoutedEventArgs e)
        {
            _group1 = SaveLoadXml.DownloadFromXml(_pathFileGroup1);
            _group2 = SaveLoadXml.DownloadFromXml(_pathFileGroup2);
            _group3 = SaveLoadXml.DownloadFromXml(_pathFileGroup3);
            _group4 = SaveLoadXml.DownloadFromXml(_pathFileGroup4);
            DataGrigInit();
        }

        private void SortGroups()
        {
            ListEmployee.SortEmployeesByAge(ref _group1);
            ListEmployee.SortEmployeesByAge(ref _group2);
            ListEmployee.SortEmployeesByAge(ref _group3);
            ListEmployee.SortEmployeesByAge(ref _group4);
        }
        private void Generate_OnClick(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Ето займет время Ви хотите ето?",
               "", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                var initial = new Task(GenerateEmployyes);
                initial.Start();
                initial.ContinueWith((t) => Dispatcher.BeginInvoke(new ThreadStart(DataGrigInit)));
            }
        }

        private void GenerateEmployyes()
        {
             var names = ListEmployee.DeserializeNames();
             _listEmployee.AddRange(ListEmployee.ParseOfRealData(names));
             _listEmployee.AddRange(ListEmployee.CreateMythicalData());
            InitGroups();
        }

        private void InitGroups()
        {
            _group1.Clear();
            _group2.Clear();
            _group3.Clear();
            _group4.Clear();
            var time = new Stopwatch();
            time.Start();
            _group1.AddRange(_listEmployee.AsParallel().Where(_predicateGroup1));
            _group2.AddRange(_listEmployee.AsParallel().Where(_predicateGroup2));
            _group3.AddRange(_listEmployee.AsParallel().Where(_predicateGroup3));
            _group4.AddRange(_listEmployee.AsParallel().Where(_predicateGroup4));
            time.Stop();
            _group1.TrimExcess();
            _group2.TrimExcess();
            _group3.TrimExcess();
            _group4.TrimExcess();
            MessageBox.Show(String.Format(
                "Сортировка {0} работников по групам зайняло {1} милесекунд",
                _listEmployee.Count,
                time.ElapsedMilliseconds));
        }

        private void DataGrigInit()
        {
            SortGroups();
            DataGridGroup1.ItemsSource = _group1;
            DataGridGroup2.ItemsSource = _group2;
            DataGridGroup3.ItemsSource = _group3;
            DataGridGroup4.ItemsSource = _group4;
        }

        private void Load_OnClick(object sender, RoutedEventArgs e)
        {
            var initial = new Task(ListEmployee.InitialXmlNames);
            initial.Start();         
        }
    }
}
