﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Serialization;

namespace Groups
{
    public static class SaveLoadXml
    {
        public static void SavetoXml(string pathFile,List<Employee> elements) 
        {
            var result = MessageBox.Show(File.Exists(pathFile) ?
               String.Format("У вас уже есть файл с работниками. Заменить файл {0} ?", pathFile)
               : String.Format("Сохранить новий файл {0}", pathFile),
               "", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                var xmlSerializer = new XmlSerializer(typeof(List<Employee>));
                using (var fs = new FileStream(pathFile, FileMode.OpenOrCreate))
                {
                    fs.SetLength(0);
                    xmlSerializer.Serialize(fs, elements);
                    fs.Flush();
                }
            }
        }

        public static List<Employee> DownloadFromXml(string pathFile)
        {
            List<Employee> employees;
            var mySerializer = new XmlSerializer(typeof(List<Employee>));
            using (var fs = new FileStream(pathFile, FileMode.Open))
            {
                employees = (List<Employee>)mySerializer.Deserialize(fs);
                fs.Close();
            }
            return employees;
        }
    }
}
